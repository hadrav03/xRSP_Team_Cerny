package com.javainuse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class TestController 
{

	@RequestMapping("/index")
	public ModelAndView IndexPage() 
	{
		return new ModelAndView("WEB-INF/views/index.jsp");
	}
	@RequestMapping("/")
	public ModelAndView Index_Page() 
	{
		return IndexPage();
	}
	
	@RequestMapping("/login")
	public ModelAndView LoginPage() 
	{
		return new ModelAndView("WEB-INF/views/login.jsp");
	}

}